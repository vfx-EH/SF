<?php
$p = "Приветствую Вас на недоработанной странице Foundry";
?>

<?php
$name = 'NUKE';
$surname = 'X';
$city = 'London';
$age = 29;
?>

<?php
include 'main.php'
?>
