<nav>
    <ul>
        <li><a href="#"> PRODUCTS </a></li>
        <li><a href="#"> SOLUTIONS </a></li>
        <li><a href="#"> COMMUNITY </a></li>
        <li><a href="#"> SUPPORT </a></li>
        <li><a href="#"> ABOUT US </a></li>
    </ul>
</nav>