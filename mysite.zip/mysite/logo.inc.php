<div class="logo">
    <img src="img/foundry_logo.svg" alt="php">
</div>
