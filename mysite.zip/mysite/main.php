<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>My site PHP Foundry</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
<div class="basa">

    <div class="header">
        <?php include 'logo.inc.php' ?>
        <?php include 'menu.inc.php' ?>
    </div>


    <div class="about_me">

        <div class="bg-logo">
            <img src="img/Foundry Imagnation Engineered 2021.jpg" alt="php">
        </div>
        <h1>  <?php echo $p ?>  </h1>

        <div class="data">

            <div class="myImg">
                <?php echo '<img src="/img/Nuke - 1920x1080.jpg" width="410">'; ?>
            </div>
            <!---->

            <div class="fullname">
                <p> Меня зовут
                    <?php echo $name, ' ', $surname . '<br>';
                    echo 'город', ' ', $city; ?>
                </p>
                <p> Мне
                    <?php echo $age; ?>
                    лет </p>
                <p> За
                    <?php echo $age; ?>
                    лет я так и не научился исправлять старые ошибки </p>
                <p>Однако можешь купить меня всего лишь за $10,268</p>
            </div>
        </div>

        <div class="knowledge">

            <?php include 'knowledge.inc.php'; ?>
            <?php echo $a, ' ', $b, ' ', $c, ' ', $d; ?> <br>

            <?php
            $a = 10;
            $b = 20;
            $c = $a + $b;
            echo $c;
            ?> <br>
            <?php
            echo $e;
            ?>
            <!---->
                    </div>

                    <div class="article">
                        <p class="text">
                            Headquarters - London
                            5 Golden Square
                            London, W1F 9HT
                            United Kingdom

                            info@foundry.com

                            +44 20 7479 4350
                        </p>
                    </div>
        </div>


        <?php include 'footer.inc.php' ?>
    </div>

</body>
</html>
